# Explaination of Mod Extras' RPY files

### **achievements.rpy**
This file was introduced in Version 3.0.0 of the mod template. This file contains the code for the achievements menu and notification that shows your progress throughout the mod.

### **bsod.rpy**
This file was introduced in Version 2.4.9 of the mod template. This file contains the code to call a fake Blue Screen of Death/Kernel Panic to the players' computer.

### **gallery.rpy**

This file was introduced in Version 3.0.0 of the mod template. This file contains the code for the gallery menu that shows backgrounds and sprites from your mod.

### **pronoun_example.rpy**

This file was introduced in Version 2.4.8 of the mod template. This file allows players to input their given pronouns into the game.