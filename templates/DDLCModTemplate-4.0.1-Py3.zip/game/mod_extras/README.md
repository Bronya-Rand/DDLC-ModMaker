# Explaination of Mod Extras' RPY files

### **achievements.rpy**
This file was introduced in Version 3.0.0 of the mod template. This file contains the code for the achievements menu and notification that shows your progress throughout the mod.

### **bsod.rpy**
This file was introduced in Version 2.4.9 of the mod template. This file contains the code to call a fake Blue Screen of Death/Kernel Panic to the players' computer.

### **extras_screen.rpy**

This file was introduced in Version 3.0.1 of the mod template. This file contains the code for the extras menu that allows multiple screens to be selected without cluttering the main options.

### **gallery.rpy**

This file was introduced in Version 3.0.0 of the mod template. This file contains the code for the gallery menu that shows backgrounds and sprites from your mod.

### **pronouns.rpy**

This file was introduced in Version 2.4.8 of the mod template. This file allows players to input their given pronouns into the game.