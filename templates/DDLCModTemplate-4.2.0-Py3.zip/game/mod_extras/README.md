# Contents

## achievements.rpy
This file contains the code for the achievements menu and notification that shows your progress throughout the mod.

## bsod.rpy
This file contains the code to call a fake Blue Screen of Death/Kernel Panic to the players' computer.

## extras_screen.rpy

This file contains the code for the extras menu that allows multiple screens to be selected without cluttering the main options.

## gallery.rpy

This file contains the code for the gallery menu that shows backgrounds and sprites from your mod.

## pronouns.rpy

This file allows players to input their given pronouns into the game.