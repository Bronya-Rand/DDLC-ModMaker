# Contents

## console.rpy
This file defines the code for Monika's console that appears at the end of Act Two through Act Four.

## glitchtext.rpy
This file defines the glitched/corrupted text seen in Act Two through Four of the game.

## poems_special.rpy
This file defines the special poems that the player can see during Act Two. Only three poems are ever shown to the player which are selected at random by `splash.rpy` (in *definitions* folder).