# Contents

## poemwords.txt
This file contains the words that can be used to write your poem and the like value to the words for each character from 1 (Bad) to 3 (Good).
   > Syntax: `word, s_like, n_like, y_like`
   
   > `word`: string, `s_like`: integer, `n_like`: integer, `y_like`: integer

## script-poemgame.rpy
This file contains the code for the poemgame at the end of each day in Act One to Act Two and a corrupted poemgame in Act Three.