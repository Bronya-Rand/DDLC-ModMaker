# Contents

## poems.rpy
This file contains the poems that are shown to the player during the Poem Sharing portion of DDLC.

## script-poemresponses.rpy
This file contains the code for the poem responses that occur in Act One and Two of the game.