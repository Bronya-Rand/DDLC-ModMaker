# Better Screen Tear Installation

Copy `effects_tear.rpy` to *game/definitions*.
> If you use this tear effect, refer to the file on using this special tear effect.